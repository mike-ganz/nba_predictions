#!/usr/bin/env pwsh
# NBA Predictions GCP Monitoring Script - Pure PowerShell Syntax

Write-Host "NBA Predictions GCP Monitoring Dashboard" -ForegroundColor Green
Write-Host "=" * 60

function Get-VMStatus {
    Write-Host "`n🖥️  VM Status:" -ForegroundColor Cyan
    try {
        $vmStatus = gcloud compute instances list --filter="name:nba-orchestrator" --format="value(status)" --project=utopian-outlook-470922-q2 2>$null
        if ($vmStatus -eq "RUNNING") {
            Write-Host "   ✅ VM is running" -ForegroundColor Green
        } else {
            Write-Host "   ❌ VM status: $vmStatus" -ForegroundColor Red
        }
    } catch {
        Write-Host "   ❌ Cannot check VM status" -ForegroundColor Red
    }
}

function Get-ProcessStatus {
    Write-Host "`n🔄 Process Status:" -ForegroundColor Cyan
    try {
        $processes = gcloud compute ssh nba-orchestrator --zone=us-central1-a --project=utopian-outlook-470922-q2 --ssh-flag="-batch" --command="ps aux | grep enhanced_orchestrator | grep -v grep" 2>$null
        
        if ($processes -and $processes.Trim()) {
            Write-Host "   ✅ Enhanced orchestrator running:" -ForegroundColor Green
            $processes -split "`n" | ForEach-Object {
                if ($_ -match "enhanced_orchestrator" -and $_ -notmatch "grep") {
                    $parts = $_ -split '\s+', 11
                    if ($parts.Length -ge 3) {
                        $cpu = $parts[2]
                        $mem = $parts[3]
                        Write-Host "     CPU: $cpu% Memory: $mem%" -ForegroundColor White
                    }
                }
            }
        } else {
            Write-Host "   ❌ No enhanced orchestrator processes running" -ForegroundColor Red
        }
    } catch {
        Write-Host "   ❌ Cannot check process status" -ForegroundColor Red
    }
}

function Get-RecentLogs {
    Write-Host "`n📋 Recent Log Entries:" -ForegroundColor Cyan
    try {
        # Try each log file individually 
        $logFiles = @("big_run_fixed.log", "big_run_multithreaded.log", "big_run_simulation.log", "orchestrator_gcp.log")
        $foundLog = $false
        
        foreach ($logFile in $logFiles) {
            # First check if file exists
            $fileExists = gcloud compute ssh nba-orchestrator --zone=us-central1-a --project=utopian-outlook-470922-q2 --ssh-flag="-batch" --command="test -f $logFile && echo 'exists' || echo 'missing'" 2>$null
            
            if ($fileExists -match "exists") {
                # File exists, get the logs
                $logs = gcloud compute ssh nba-orchestrator --zone=us-central1-a --project=utopian-outlook-470922-q2 --ssh-flag="-batch" --command="tail -10 $logFile | strings | grep -E 'ITERATION|NEW PLAY|Game State|ERROR|threads'" 2>$null
                
                if ($logs -and $logs.Trim()) {
                    Write-Host "   📄 From $logFile (most recent):" -ForegroundColor Yellow
                    $logs -split "`n" | Select-Object -Last 5 | ForEach-Object {
                        if ($_ -and $_.Trim()) {
                            Write-Host "     $_" -ForegroundColor White
                        }
                    }
                    $foundLog = $true
                    break
                }
            }
        }
        
        if (-not $foundLog) {
            Write-Host "   ⚠️  No recent log entries found" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "   ❌ Cannot retrieve logs" -ForegroundColor Red
    }
}

function Get-DatabaseStats {
    Write-Host "`n🗄️  Database Status:" -ForegroundColor Cyan
    try {
        $dbFiles = gcloud compute ssh nba-orchestrator --zone=us-central1-a --project=utopian-outlook-470922-q2 --ssh-flag="-batch" --command="ls -lh *.db 2>/dev/null" 2>$null
        
        if ($dbFiles -and $dbFiles.Trim()) {
            Write-Host "   📊 Database files:" -ForegroundColor Green
            $dbFiles -split "`n" | Where-Object { $_ -match "\.db" } | ForEach-Object {
                $parts = $_ -split '\s+', 9
                if ($parts.Length -ge 5) {
                    $size = $parts[4]
                    $name = $parts[8]
                    Write-Host "     $name ($size)" -ForegroundColor White
                }
            }
        } else {
            Write-Host "   ⚠️  No database files found" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "   ❌ Cannot check database files" -ForegroundColor Red
    }
}

function Show-Menu {
    Write-Host "`n🎮 Options:" -ForegroundColor Cyan
    Write-Host "   r - Refresh dashboard"
    Write-Host "   l - View live logs (tail -f)"
    Write-Host "   s - SSH to VM"
    Write-Host "   d - Download latest database"
    Write-Host "   q - Quit"
    
    $choice = Read-Host "`nEnter choice (r/l/s/d/q)"
    return $choice
}

# Main monitoring loop
do {
    Clear-Host
    Write-Host "NBA Predictions GCP Monitoring Dashboard" -ForegroundColor Green
    Write-Host "=" * 60
    Write-Host "Last updated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
    
    Get-VMStatus
    Get-ProcessStatus  
    Get-RecentLogs
    Get-DatabaseStats
    
    $choice = Show-Menu
    
    switch ($choice) {
        "l" {
            Write-Host "`nStarting live log view (Ctrl+C to return)..." -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            # Try different log files in order of preference
            $logCommand = "tail -f big_run_fixed.log 2>/dev/null || tail -f big_run_multithreaded.log 2>/dev/null || tail -f big_run_simulation.log 2>/dev/null || echo 'No log files found'"
            gcloud compute ssh nba-orchestrator --zone=us-central1-a --project=utopian-outlook-470922-q2 --ssh-flag="-batch" --command="$logCommand"
        }
        "s" {
            Write-Host "`nConnecting to VM..." -ForegroundColor Yellow
            gcloud compute ssh nba-orchestrator --zone=us-central1-a --project=utopian-outlook-470922-q2
        }
        "d" {
            Write-Host "`nDownloading latest database..." -ForegroundColor Yellow
            # Try to download the most recent database
            $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
            gcloud compute scp "nba-orchestrator:enhanced_simulation_results_multithreaded.db" "./enhanced_simulation_results_$timestamp.db" --zone=us-central1-a --project=utopian-outlook-470922-q2 --scp-flag="-batch"
            Write-Host "Download completed as enhanced_simulation_results_$timestamp.db!" -ForegroundColor Green
            Read-Host "Press Enter to continue"
        }
        "q" {
            Write-Host "`nExiting monitor..." -ForegroundColor Yellow
            break
        }
        default {
            # Default is refresh (including "r")
            Start-Sleep -Seconds 1
        }
    }
} while ($choice -ne "q")

Write-Host "`nMonitoring session ended." -ForegroundColor Gray