"""
Google Gemini training data formatting utilities.

This module handles conversion of NBA training data to the official Google Cloud 
Vertex AI Gemini fine-tuning format using the "GenerateContent" structure with user/model roles.

Format: {"contents": [{"role": "user", "parts": [{"text": "..."}]}, {"role": "model", "parts": [{"text": "..."}]}]}
"""

import json
from typing import List, Dict, Any, Optional
import pandas as pd
from game.time_utils import convert_to_quarter_time
from game.scoring_utils import determine_scoring_info
from data.file_utils import file_manager
from training.data_generator import extract_players_on_court, process_play_description, normalize_shot_coordinates
from training.base_formatter import BaseFormatter, FormatterFactory
from config.settings import DEFAULT_N_TOTAL_PLAYS


class GeminiFormatter(BaseFormatter):
    """Handles conversion to Google Gemini fine-tuning format."""
    
    @property
    def platform_name(self) -> str:
        """Return the platform name."""
        return "Gemini"
    
    def create_training_data(self, df: pd.DataFrame, generation_mode: str = "remaining_plays") -> List[Dict[str, Any]]:
        """
        Convert our JSON training data into Gemini fine-tuning JSONL format.
        Handles two generation modes:
        - remaining_plays: Skip first N plays, then create input-output pairs with full context
        - first_N_plays: Single entry per game with first N plays as targets
        
        Args:
            df: DataFrame with 'json_training_data' column
            generation_mode: "remaining_plays" or "first_N_plays"
            
        Returns:
            list: List of training examples in Gemini format
        """
        training_examples = []
        
        if generation_mode == "first_N_plays":
            # Mode 2: Single entry per game with first N plays as targets
            for game_id in sorted(df['game_id'].unique()):
                game_df = df[df['game_id'] == game_id].sort_values('play_id').reset_index(drop=True)
                
                # Find the first row with valid JSON context (should be the first row)
                context_row = None
                for i in range(len(game_df)):
                    json_data = game_df.iloc[i]['json_training_data']
                    if json_data and json_data.strip() and json_data.strip() != "{}":
                        try:
                            # Test if it's valid JSON and has team data
                            parsed = json.loads(json_data)
                            if 'away_team' in parsed and 'home_team' in parsed:
                                context_row = game_df.iloc[i]
                                break
                        except json.JSONDecodeError:
                            continue
                
                if context_row is not None:
                    example = self._create_first_n_plays_example(game_df, context_row)
                    if example:
                        training_examples.append(example)
        else:
            # Mode 1: Standard remaining_plays pairs
            for game_id in sorted(df['game_id'].unique()):
                game_df = df[df['game_id'] == game_id].sort_values('play_id').reset_index(drop=True)
                
                # Create training examples for consecutive plays  
                for i in range(len(game_df) - 1):  # -1 because we need a next play
                    # Skip rows with invalid JSON data (placeholders from first N plays)
                    current_json_data = game_df.iloc[i]['json_training_data']
                    if not current_json_data or current_json_data.strip() == "" or current_json_data.strip() == "{}":
                        continue
                    
                    example = self._create_training_example(game_df, i)
                    if example:
                        training_examples.append(example)
        
        return training_examples
    
    def _create_training_example(self, game_df: pd.DataFrame, current_index: int) -> Optional[Dict[str, Any]]:
        """
        Create a single Gemini training example from current and next plays.
        
        Args:
            game_df: DataFrame for a single game, sorted by play_id
            current_index: Index of current play
            
        Returns:
            dict or None: Gemini training example or None if creation failed
        """
        try:
            current_row = game_df.iloc[current_index]
            next_row = game_df.iloc[current_index + 1]
            
            # Parse the current JSON context
            current_json = json.loads(current_row['json_training_data'])
            
            # Create the next play response
            assistant_response = self._create_next_play_response(
                game_df, current_index, next_row, current_json
            )
            
            # Create Gemini training example using GenerateContent format
            # OLD (messages format - commented out for easy revert):
            # training_example = {
            #     "messages": [
            #         {
            #             "role": "user",
            #             "content": current_row['json_training_data']  # Our JSON context
            #         },
            #         {
            #             "role": "model",
            #             "content": json.dumps(assistant_response, separators=(',', ':'))
            #         }
            #     ]
            # }
            
            # NEW (GenerateContent format):
            training_example = {
                "contents": [
                    {
                        "role": "user",
                        "parts": [{"text": current_row['json_training_data']}]  # Our JSON context
                    },
                    {
                        "role": "model", 
                        "parts": [{"text": json.dumps(assistant_response, separators=(',', ':'))}]
                    }
                ]
            }
            
            return training_example
            
        except (json.JSONDecodeError, KeyError, ValueError, IndexError) as e:
            print(f"Warning: Skipped Gemini training example due to error: {e}")
            return None
    
    def _create_first_n_plays_example(self, game_df: pd.DataFrame, context_row: pd.Series) -> Optional[Dict[str, Any]]:
        """
        Create a single first-N-plays Gemini training example.
        
        Args:
            game_df: DataFrame for a single game
            context_row: Row containing the game context without recent_plays
            
        Returns:
            dict or None: Gemini training example or None if creation failed
        """
        try:
            # Parse the context JSON
            context_json = json.loads(context_row['json_training_data'])
            
            # Get first N non-null plays from the raw DataFrame data
            first_plays = []
            n_total = DEFAULT_N_TOTAL_PLAYS  # Number of plays to include (configurable)
            
            for i in range(len(game_df)):
                if len(first_plays) >= n_total:
                    break
                    
                row = game_df.iloc[i]
                if pd.notna(row.get('description')):
                    # Create play object similar to recent_plays format
                    play_obj = self._create_play_object(row, context_json, game_df)
                    first_plays.append(play_obj)
            
            # Create the response with first N plays (matching OpenAI format)
            assistant_response = {
                "next_plays": first_plays  # Changed from "first_N_plays" to "next_plays" for consistency
            }
            
            # Create Gemini training example using GenerateContent format
            # OLD (messages format - commented out for easy revert):
            # training_example = {
            #     "messages": [
            #         {
            #             "role": "user",
            #             "content": context_row['json_training_data']  # Context without recent_plays
            #         },
            #         {
            #             "role": "model",
            #             "content": json.dumps(assistant_response, separators=(',', ':'))
            #         }
            #     ]
            # }
            
            # NEW (GenerateContent format):
            training_example = {
                "contents": [
                    {
                        "role": "user",
                        "parts": [{"text": context_row['json_training_data']}]  # Context without recent_plays
                    },
                    {
                        "role": "model",
                        "parts": [{"text": json.dumps(assistant_response, separators=(',', ':'))}]
                    }
                ]
            }
            
            return training_example
            
        except (json.JSONDecodeError, KeyError, ValueError, IndexError) as e:
            print(f"Warning: Skipped first_N_plays Gemini training example due to error: {e}")
            return None
    
    def _create_play_object(self, row: pd.Series, current_json: Dict[str, Any], game_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Create a play object from a DataFrame row.
        
        Args:
            row: DataFrame row with play data
            current_json: Current game context for team names
            game_df: Full game DataFrame for scoring calculations
            
        Returns:
            dict: Play object in the expected format
        """
        # Get quarter and time
        quarter, time_in_quarter = convert_to_quarter_time(
            row['period'], row['remaining_time']
        )
        
        # Calculate scoring by comparing with previous play in the game
        scoring_team = None
        points_scored = 0
        
        # Find the current row index in the game DataFrame using positional index
        current_row_index = None
        for pos_idx in range(len(game_df)):
            game_row = game_df.iloc[pos_idx]
            if (game_row['play_id'] == row['play_id'] and 
                game_row['game_id'] == row['game_id']):
                current_row_index = pos_idx
                break
        
        # If we found the current row and it's not the first row, calculate scoring
        if current_row_index is not None and current_row_index > 0:
            prev_row = game_df.iloc[current_row_index - 1]
            prev_away_score = prev_row.get('away_score', 0) or 0
            prev_home_score = prev_row.get('home_score', 0) or 0
            curr_away_score = row.get('away_score', 0) or 0
            curr_home_score = row.get('home_score', 0) or 0
            
            scoring_team, points_scored = determine_scoring_info(
                prev_away_score, prev_home_score,
                curr_away_score, curr_home_score,
                current_json['away_team']['name'], current_json['home_team']['name']
            )
        
        # Format score
        away_team_name = current_json['away_team']['name']
        home_team_name = current_json['home_team']['name']
        score = f"{away_team_name} {int(row.get('away_score', 0) or 0)} - {home_team_name} {int(row.get('home_score', 0) or 0)}"
        
        # Get player
        player = row.get('player')
        
        # Create shot_details object - populated only for shots
        event_type = row.get('event_type', '')
        if event_type == 'shot':
            # For shots, determine the shooting team from the row data
            shooting_team = row.get('team', '')  # Get team that took the shot
            
            # Apply coordinate normalization for shots (commented out for now)
            # raw_x = row.get('converted_x')
            # raw_y = row.get('converted_y')
            # x_norm, y_norm = normalize_shot_coordinates(raw_x, raw_y)
            
            shot_details = {
                "team": str(shooting_team) if shooting_team else None,
                "points": int(points_scored)
                # "x_coord": x_norm,  # Commented out - can be re-enabled later
                # "y_coord": y_norm   # Commented out - can be re-enabled later
            }
        else:
            shot_details = {
                "team": None,
                "points": None
                # "x_coord": None,  # Commented out - can be re-enabled later
                # "y_coord": None   # Commented out - can be re-enabled later
            }
        
        return {
            "quarter": int(quarter),
            "time_remaining": str(time_in_quarter),
            "score": score,
            "players_on_court": extract_players_on_court(row, current_json['away_team']['name'], current_json['home_team']['name']),
            "player": str(player) if pd.notna(player) else None,
            "description": process_play_description(row),
            "shot_details": shot_details  # Use shot_details format consistent with other formatters
        }
    
    def _create_next_play_response(self, game_df: pd.DataFrame, current_index: int, 
                                 next_row: pd.Series, current_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create the assistant response (next play prediction) for Gemini training.
        
        Args:
            game_df: DataFrame for the game
            current_index: Index of current play
            next_row: Next play data
            current_json: Parsed JSON context from current play
            
        Returns:
            dict: Assistant response with next play information
        """
        # Get quarter and time for next play
        next_quarter, next_time = convert_to_quarter_time(
            next_row['period'], next_row['remaining_time']
        )
        
        # Determine scoring info for next play
        prev_away_score, prev_home_score = self._get_previous_scores(game_df, current_index)
        
        scoring_team, points_scored = determine_scoring_info(
            prev_away_score, prev_home_score,
            next_row['away_score'], next_row['home_score'], 
            current_json['away_team']['name'], current_json['home_team']['name']
        )
        
        # VALIDATION: Check for obvious mismatches (steal/turnover/miss with scoring)
        next_desc = str(next_row['description']).upper()
        is_non_scoring_play = any(word in next_desc for word in [
            'STEAL', 'TURNOVER', 'MISS', 'REBOUND', 'FOUL', 'SUB:', 'TIMEOUT'
        ])
        
        if is_non_scoring_play and points_scored > 0:
            # This should not happen - debug log the issue
            print(f"⚠️ Scoring mismatch detected:")
            print(f"   Description: {next_row['description']}")
            print(f"   Scores: {prev_away_score}-{prev_home_score} → {next_row['away_score']}-{next_row['home_score']}")
            print(f"   Calculated: {scoring_team} +{points_scored}")
            # Force correction for obvious non-scoring plays
            scoring_team, points_scored = None, 0
        
        # Format score
        score = (f"{current_json['away_team']['name']} {next_row['away_score']} - "
                f"{current_json['home_team']['name']} {next_row['home_score']}")
        
        # Create shot_details object - populated only for shots
        next_event_type = next_row.get('event_type', '')
        if next_event_type == 'shot':
            # For shots, determine the shooting team from the row data
            shooting_team = next_row.get('team', '')  # Get team that took the shot
            
            # Apply coordinate normalization for shots (commented out for now)
            # raw_x = next_row.get('converted_x')
            # raw_y = next_row.get('converted_y')
            # x_norm, y_norm = normalize_shot_coordinates(raw_x, raw_y)
            
            shot_details = {
                "team": str(shooting_team) if shooting_team else None,
                "points": int(points_scored) if points_scored else 0
                # "x_coord": x_norm,  # Commented out - can be re-enabled later
                # "y_coord": y_norm   # Commented out - can be re-enabled later
            }
        else:
            shot_details = {
                "team": None,
                "points": None
                # "x_coord": None,  # Commented out - can be re-enabled later
                # "y_coord": None   # Commented out - can be re-enabled later
            }
        
        # Create the assistant response with shot_details and player info
        next_player = next_row.get('player')
        return {
            "next_play": {
                "quarter": int(next_quarter),
                "time_remaining": str(next_time),
                "score": str(score),
                "players_on_court": extract_players_on_court(next_row, current_json['away_team']['name'], current_json['home_team']['name']),
                "player": str(next_player) if pd.notna(next_player) else None,
                "description": process_play_description(next_row),
                "shot_details": shot_details
            }
        }
    
    def _get_previous_scores(self, game_df: pd.DataFrame, current_index: int) -> tuple[int, int]:
        """
        Get the scores from the current context play for next play scoring calculation.
        
        Args:
            game_df: DataFrame for the game
            current_index: Index of current context play
            
        Returns:
            tuple: (context_away_score, context_home_score)
        """
        current_row = game_df.iloc[current_index]
        return int(current_row.get('away_score', 0) or 0), int(current_row.get('home_score', 0) or 0)
    
    def validate_training_examples(self, training_examples: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Validate Gemini training examples for format compliance.
        
        Args:
            training_examples: List of training examples to validate
            
        Returns:
            dict: Validation results with errors, warnings, and statistics
        """
        validation_results = {
            'total_examples': len(training_examples),
            'valid_examples': 0,
            'errors': [],
            'warnings': [],
            'error_rate': 0.0,
            'success_rate': 0.0
        }
        
        for i, example in enumerate(training_examples):
            try:
                # Check required fields for Gemini GenerateContent format
                # OLD (messages format - commented out for easy revert):
                # if 'messages' not in example:
                #     validation_results['errors'].append(f"Example {i}: Missing 'messages' field")
                #     continue
                # 
                # messages = example['messages']
                # if not isinstance(messages, list) or len(messages) != 2:
                #     validation_results['errors'].append(f"Example {i}: 'messages' must be a list with exactly 2 entries")
                #     continue
                # 
                # # Validate user message
                # user_msg = messages[0]
                # if user_msg.get('role') != 'user':
                #     validation_results['errors'].append(f"Example {i}: First message must have role 'user'")
                #     continue
                # 
                # if 'content' not in user_msg:
                #     validation_results['errors'].append(f"Example {i}: User message missing 'content' field")
                #     continue
                # 
                # # Validate model message
                # model_msg = messages[1]
                # if model_msg.get('role') != 'model':
                #     validation_results['errors'].append(f"Example {i}: Second message must have role 'model'")
                #     continue
                # 
                # if 'content' not in model_msg:
                #     validation_results['errors'].append(f"Example {i}: Model message missing 'content' field")
                #     continue
                
                # NEW (GenerateContent format):
                if 'contents' not in example:
                    validation_results['errors'].append(f"Example {i}: Missing 'contents' field")
                    continue
                
                contents = example['contents']
                if not isinstance(contents, list) or len(contents) != 2:
                    validation_results['errors'].append(f"Example {i}: 'contents' must be a list with exactly 2 entries")
                    continue
                
                # Validate user content
                user_content = contents[0]
                if user_content.get('role') != 'user':
                    validation_results['errors'].append(f"Example {i}: First content must have role 'user'")
                    continue
                
                if 'parts' not in user_content or not isinstance(user_content['parts'], list):
                    validation_results['errors'].append(f"Example {i}: User content missing 'parts' array")
                    continue
                
                if len(user_content['parts']) != 1 or 'text' not in user_content['parts'][0]:
                    validation_results['errors'].append(f"Example {i}: User content 'parts' must contain single 'text' entry")
                    continue
                
                # Validate model content
                model_content = contents[1]
                if model_content.get('role') != 'model':
                    validation_results['errors'].append(f"Example {i}: Second content must have role 'model'")
                    continue
                
                if 'parts' not in model_content or not isinstance(model_content['parts'], list):
                    validation_results['errors'].append(f"Example {i}: Model content missing 'parts' array")
                    continue
                
                if len(model_content['parts']) != 1 or 'text' not in model_content['parts'][0]:
                    validation_results['errors'].append(f"Example {i}: Model content 'parts' must contain single 'text' entry")
                    continue
                
                # Validate user content is valid JSON with team info
                try:
                    input_text = user_content['parts'][0]['text']
                    input_content = json.loads(input_text)
                    if 'away_team' not in input_content or 'home_team' not in input_content:
                        validation_results['warnings'].append(
                            f"Example {i}: User content missing team information"
                        )
                except json.JSONDecodeError:
                    validation_results['errors'].append(f"Example {i}: User content is not valid JSON")
                    continue
                
                # Validate model content is valid JSON
                try:
                    output_text = model_content['parts'][0]['text']
                    output_content = json.loads(output_text)
                    if 'next_play' not in output_content and 'first_N_plays' not in output_content:
                        validation_results['warnings'].append(
                            f"Example {i}: Model content missing expected keys"
                        )
                except json.JSONDecodeError:
                    validation_results['errors'].append(f"Example {i}: Model content is not valid JSON")
                    continue
                
                validation_results['valid_examples'] += 1
                
            except Exception as e:
                validation_results['errors'].append(f"Example {i}: Unexpected error - {str(e)}")
        
        validation_results['error_rate'] = len(validation_results['errors']) / len(training_examples) if training_examples else 0
        validation_results['success_rate'] = validation_results['valid_examples'] / len(training_examples) if training_examples else 0
        
        return validation_results
    
    def save_training_data(self, training_examples: List[Dict[str, Any]], 
                          filename: Optional[str] = None, 
                          season_year: Optional[str] = None) -> str:
        """
        Save training examples in JSONL format for Gemini fine-tuning.
        
        Args:
            training_examples: List of training examples
            filename: Custom filename (will append '_gemini' suffix)
            season_year: Season year for filename
            
        Returns:
            str: Path to saved JSONL file
        """
        # Add Gemini-specific suffix to filename
        if filename:
            if not filename.endswith('_gemini.jsonl'):
                # Remove existing extension and add gemini suffix
                base_name = filename.replace('.jsonl', '').replace('_openai', '')
                filename = f"{base_name}_gemini.jsonl"
        
        return file_manager.save_openai_training_data(training_examples, filename, season_year)


class GeminiDatasetGenerator:
    """High-level interface for generating Gemini datasets."""
    
    def __init__(self):
        self.formatter = GeminiFormatter()
    
    def generate_for_game(self, game_id: int, season_year: str = "2023-2024", 
                         n_total: int = 5, max_plays: Optional[int] = None) -> tuple[List[Dict[str, Any]], str]:
        """
        Generate Gemini fine-tuning data for a specific game.
        
        Args:
            game_id: Game ID to generate training data for
            season_year: Season year
            n_total: Number of recent plays in context
            max_plays: Max plays to process (None for all)
            
        Returns:
            tuple: (training_examples_list, jsonl_filepath)
        """
        from training.data_generator import training_data_generator
        
        print(f"Generating Gemini training data for game {game_id}...")
        
        # Generate our structured JSON data first
        df = training_data_generator.generate_for_game(game_id, season_year, n_total, max_plays)
        
        # Convert to Gemini format
        training_examples = self.formatter.create_training_data(df)
        
        # Save as JSONL
        jsonl_path = self.formatter.save_training_data(
            training_examples, 
            filename=f"game_{game_id}_gemini_training.jsonl",
            season_year=season_year
        )
        
        return training_examples, jsonl_path
    
    def generate_dataset(self, season_year: Optional[str] = None, 
                        n_total: int = 5, sample_size: Optional[int] = None, 
                        game_id_filter: Optional[List[int]] = None) -> tuple[List[Dict[str, Any]], str]:
        """
        Generate Gemini fine-tuning data for multiple games.
        
        Args:
            season_year: Season to process (None for latest)
            n_total: Number of recent plays in context
            sample_size: Number of games to sample (None for all)
            game_id_filter: Specific game IDs to process
            
        Returns:
            tuple: (training_examples_list, jsonl_filepath)
        """
        from training.data_generator import training_data_generator
        
        print(f"Generating Gemini dataset for season {season_year}...")
        
        # Generate structured JSON data
        df = training_data_generator.generate_dataset(
            season_year=season_year,
            n_total=n_total,
            sample_size=sample_size,
            game_id_filter=game_id_filter
        )
        
        # Convert to Gemini format
        training_examples = self.formatter.create_training_data(df)
        
        # Save as JSONL
        jsonl_path = self.formatter.save_training_data(
            training_examples,
            season_year=season_year
        )
        
        return training_examples, jsonl_path


# Global instances for easy access
gemini_formatter = GeminiFormatter()
gemini_dataset_generator = GeminiDatasetGenerator()

# Register Gemini formatter with the factory
FormatterFactory.register_formatter("gemini", GeminiFormatter)


# Convenience functions for Gemini training data
def save_gemini_training_data(training_examples: List[Dict[str, Any]], 
                            filename: Optional[str] = None, 
                            season_year: Optional[str] = None) -> str:
    """Save training examples in JSONL format for Gemini fine-tuning."""
    return gemini_formatter.save_training_data(training_examples, filename, season_year)


def generate_gemini_training_for_game(game_id: int, season_year: str = "2023-2024", 
                                    n_total: int = 5, max_plays: Optional[int] = None) -> tuple[List[Dict[str, Any]], str]:
    """Generate Gemini fine-tuning data for a specific game."""
    return gemini_dataset_generator.generate_for_game(game_id, season_year, n_total, max_plays)
